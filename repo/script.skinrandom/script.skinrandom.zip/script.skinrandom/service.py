import os, shutil, re, urllib2, unicodedata, time
import xbmc, xbmcgui, xbmcaddon, xbmcvfs
import json, random

ADDON = xbmcaddon.Addon('script.skinrandom')
ADDONID = ADDON.getAddonInfo('id')
ADDONNAME = ADDON.getAddonInfo('name')
ADDONVERSION = ADDON.getAddonInfo('version')
LANGUAGE = ADDON.getLocalizedString
SETTING = ADDON.getSetting

def log(txt):
    if isinstance (txt,str):
        txt = txt.decode("utf-8")
    message = u'%s: %s' % (ADDONID, txt)
    xbmc.log(msg=message.encode("utf-8"), level=xbmc.LOGDEBUG)

def clean_filename(filename):
    illegal_char = '^<>:"/\|?*'
    for char in illegal_char:
        filename = filename.replace( char , '' )
    return filename

class Main:
    def __init__ ( self ):
        self._load_settings()
        #self._delete_directories()
        ok = self._load_files()
        if ok:
            self._create_variable()
            self.run()



    def run(self):
        kodimonitor = xbmc.Monitor()
        num = float(SETTING('time'))
        while not kodimonitor.abortRequested():
            self._create_sheme()
            self._create_directories()
            xbmc.executebuiltin('ReloadSkin()')
            print('Before: %s' % time.ctime())
            time.sleep(num)
            print('After: %s\n' % time.ctime())
            kodimonitor.waitForAbort(10)



    def _load_settings( self ):
        self.skin = xbmc.getSkinDir()
        myskin = xbmcaddon.Addon(id=self.skin)
        self.path_dir = xbmc.translatePath(myskin.getAddonInfo('path') ).decode('utf-8')
        name = xbmc.translatePath(myskin.getAddonInfo('name') ).decode('utf-8')
        #C:\Program Files (x86)\Kodi\addons\skin.estuary
        self.realdir = os.path.join(xbmc.translatePath("special://home/"), 'addons' , self.skin).decode('utf-8')

        self.defaultfiles =  os.path.join( self.path_dir, 'colors', 'defaults.xml' ).decode('utf-8')

        self.randomfiles =  os.path.join( self.path_dir, 'colors', 'random.xml' ).decode('utf-8')


        self.dialog = xbmcgui.DialogProgress()
        self.variable = []
        self.colors = []
            #self.directory = xbmc.translatePath(xbmcaddon.Addon().getAddonInfo('profile')).decode('utf-8')
            #self.moviefanartpath = os.path.join( self.directory, self.moviefanartdir )
            #self.tvshowfanartpath = os.path.join( self.directory, self.tvshowfanartdir )


    def _load_files(self):
        #ne fonctionne pas
        #if xbmcvfs.exists(self.path_dir):
        if os.path.exists(self.path_dir) and not os.path.exists(self.realdir):
            try:
                ok = shutil.copytree(self.path_dir,  self.realdir)
                log('Dossier Skin copier')
                xbmc.executebuiltin('ReloadSkin()')
                return True
            except:
                log('Impossible de copie le dossier')
        elif os.path.exists(self.realdir):
            return True
        return False


    def _create_directories( self ):
        info = xbmcvfs.File(self.randomfiles, 'w')
        info.write('<?xml version="1.0" encoding="UTF-8"?>\n<colors>\n')

        for var, color in self.variable:
            info.write('<color name="%s">%s</color>\n' % (var,color))

        info.write('</colors>')
        info.close()

    def _create_variable( self ):
        info = xbmcvfs.File(self.defaultfiles)
        content = info.read()
        regex = r'<color name="(.+?)">(.+?)</color>'
        matches = re.findall(regex, content)

        for var, color in matches:
            variable = [var,color]
            self.variable.append(variable)

    def _create_sheme( self ):

        r = random.randint(0,255)
        g = random.randint(0,255)
        b = random.randint(0,255)
        count = len(self.variable)
        url = 'http://www.thecolorapi.com/scheme?rgb=%s,%s,%s&format=json&mode=analogic&count=%s' % (r, g, b, count)

        request = urllib2.Request(url)
        response = urllib2.urlopen(request)
        data = json.loads(response.read().decode('utf-8'))

        for i, e in enumerate(data['colors']):
            news_color = '%s%s' % (self.variable[i][1][0:2], str(e['hex']['clean']))
            self.variable[i][1] = news_color



if ( __name__ == "__main__" ):
    log('script version %s started' % ADDONVERSION)
    Main()
log('script stopped')
