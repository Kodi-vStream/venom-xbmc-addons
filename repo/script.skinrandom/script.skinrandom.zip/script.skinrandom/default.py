import xbmc, xbmcgui, xbmcaddon, xbmcvfs


ADDON = xbmcaddon.Addon()
ADDONID = ADDON.getAddonInfo('id')
ADDONNAME = ADDON.getAddonInfo('name')
ADDONVERSION = ADDON.getAddonInfo('version')
LANGUAGE = ADDON.getLocalizedString

class Main:
    def __init__ ( self ):
        ADDON.openSettings()


if ( __name__ == "__main__" ):
    Main()
