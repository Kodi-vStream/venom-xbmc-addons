# -*- coding: utf-8 -*-
# https://github.com/Kodi-vStream/venom-xbmc-addons

from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.parser import cParser
from resources.hosters.hoster import iHoster
from resources.lib import util

UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:139.0) Gecko/20100101 Firefox/139.0'

class cHoster(iHoster):

    def __init__(self):
        iHoster.__init__(self, 'vidmoly', 'VidMoly')

    def __getIdFromUrl(self):
        id = self._url.split('/')[-1]
        id = id.split(".")[0]
        id =id.replace("embed-","")
        return id

    def _getMediaLinkForGuest(self):
        api_call = ''
        oParser = cParser()
        
        self._url = self._url.replace('vidmoly.to', 'vidmoly.net')
        
        if '/w/' in self._url:
            oRequest = cRequestHandler(self._url)
            oRequest.addHeaderEntry('User-Agent', UA)
            sHtmlContent = oRequest.request()
            sPattern = 'iframe src="//([^"]+)"'
            aResult = oParser.parse(sHtmlContent, sPattern)
            if aResult[0]:
                self._url = 'https://' + aResult[1][0]

        elif '/v/' in self._url:
            oRequest = cRequestHandler(self._url)
            oRequest.addHeaderEntry('User-Agent', UA)
            sHtmlContent = oRequest.request()
            sPattern = 'iframe.+?src="([^"]+)"'
            aResult = oParser.parse(sHtmlContent, sPattern)
            if aResult[0]:
                self._url = aResult[1][0]

        oRequest = cRequestHandler(self._url)
        oRequest.addHeaderEntry('User-Agent', UA)
        oRequest.addHeaderEntry('Referer', self._url)
        oRequest.addHeaderEntry('Cookie', "cf_turnstile_demo_pass_" + self.__getIdFromUrl() + "=1")
        sHtmlContent = oRequest.request()

        sPattern = "sources: *\\[ *\\{ *file: *'([^']+)'"
        aResult = oParser.parse(sHtmlContent, sPattern)

        if aResult[0] is True:
            api_call = aResult[1][0]
            #api_call = api_call.replace(',', '').replace('.urlset', '')
            api_call = api_call + '|Referer=' + util.urlHostName(self._url)
            return True, api_call

        return False, False
