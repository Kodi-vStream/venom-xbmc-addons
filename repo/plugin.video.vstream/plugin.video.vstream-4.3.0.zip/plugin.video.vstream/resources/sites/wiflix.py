# -*- coding: utf-8 -*-
# vStream https://github.com/Kodi-vStream/venom-xbmc-addons

from resources.lib.comaddon import siteManager
from resources.lib.gui.hoster import cHosterGui
from resources.lib.gui.gui import cGui
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.outputParameterHandler import cOutputParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.parser import cParser
from resources.lib.util import urlHostName, cUtil

import re
import json

UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36'

SITE_IDENTIFIER = 'wiflix'
SITE_NAME = 'Wiflix'
SITE_DESC = 'Films & Séries en streaming'

MOVIE_MOVIE = (True, 'showMenuMovies')
MOVIE_NEWS = ('film-en-streaming/', 'showMovies')
MOVIE_VIEWS = ('film-en-streaming/exclue', 'showMovies')
MOVIE_GENRES = (True, 'showGenres')

SERIE_SERIES = (True, 'showMenuSeries')
SERIE_NEWS = ('serie-en-streaming/', 'showSeries')

URL_SEARCH = ('index.php?do=search', 'showSearch')
URL_SEARCH_MOVIES = ('', 'showMovies')
URL_SEARCH_SERIES = ('', 'showSeries')
FUNCTION_SEARCH = 'showSearch'


def getUrlMain():
    siteInfo = siteManager().getDefaultProperty(SITE_IDENTIFIER, 'site_info')
    if siteInfo:
        oParser = cParser()
        oRequestHandler = cRequestHandler(siteInfo)
        sHtmlContent = oRequestHandler.request()

        sPattern = "location.href *= *atob\(([^\)]+)"
        aResult = oParser.parse(sHtmlContent, sPattern)
        if aResult[0]:
            payload = aResult[1][0]
            sPattern = '%s *= *"([^\"]+)' % payload
            aResult = oParser.parse(sHtmlContent, sPattern)
            if aResult[0]:
                import base64
                sUrl = base64.b64decode(aResult[1][0])
                sUrl = str(sUrl).strip("b'")
                if not sUrl.endswith('/'):
                    sUrl = sUrl + '/'
                return sUrl

        sPattern = "location.href *= *'(.+?)'"
        aResult = oParser.parse(sHtmlContent, sPattern)
        if aResult[0]:
            sUrl = aResult[1][0]
            if not sUrl.endswith('/'):
                sUrl = sUrl + '/'
            return sUrl

    return siteManager().getUrlMain(SITE_IDENTIFIER)


def load():
    oGui = cGui()

    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'http://film')
    oGui.addDir(SITE_IDENTIFIER, 'showSearch', 'Recherche Films', 'search-films.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', 'http://serie')
    oGui.addDir(SITE_IDENTIFIER, 'showSearch', 'Recherche Séries', 'search-series.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', MOVIE_VIEWS[0])
    oGui.addDir(SITE_IDENTIFIER, MOVIE_VIEWS[1], 'Films (Populaires)', 'popular.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', MOVIE_NEWS[0])
    oGui.addDir(SITE_IDENTIFIER, MOVIE_NEWS[1], 'Films (Derniers ajouts)', 'news.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', MOVIE_GENRES[0])
    oGui.addDir(SITE_IDENTIFIER, MOVIE_GENRES[1], 'Films (Genres)', 'genres.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_NEWS[0])
    oGui.addDir(SITE_IDENTIFIER, SERIE_NEWS[1], 'Séries (Derniers ajouts)', 'news.png', oOutputParameterHandler)

    # oOutputParameterHandler.addParameter('siteUrl', SERIE_LIST[0])
    # oGui.addDir(SITE_IDENTIFIER, SERIE_LIST[1], 'Séries (Liste)', 'az.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()


def showMenuMovies():
    oGui = cGui()

    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'http://film')
    oGui.addDir(SITE_IDENTIFIER, 'showSearch', 'Rechercher', 'search.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', MOVIE_VIEWS[0])
    oGui.addDir(SITE_IDENTIFIER, MOVIE_VIEWS[1], 'Populaires', 'popular.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', MOVIE_NEWS[0])
    oGui.addDir(SITE_IDENTIFIER, MOVIE_NEWS[1], 'Derniers ajouts', 'news.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', MOVIE_GENRES[0])
    oGui.addDir(SITE_IDENTIFIER, MOVIE_GENRES[1], 'Par genres', 'genres.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()


def showMenuSeries():
    oGui = cGui()

    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'http://serie')
    oGui.addDir(SITE_IDENTIFIER, 'showSearch', 'Rechercher', 'search.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_NEWS[0])
    oGui.addDir(SITE_IDENTIFIER, SERIE_NEWS[1], 'Derniers ajouts', 'news.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()


def showSearch():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')

    sSearchText = oGui.showKeyBoard()
    if sSearchText:

        if 'film' in sUrl:
            showMovies(sSearchText)
        else:
            showSeries(sSearchText)

        oGui.setEndOfDirectory()
        return


def showGenres():
    oGui = cGui()
    oParser = cParser()

    sUrl = getUrlMain()
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()
    sStart = '</span><b>Films par genre</b></div>'
    sEnd = '<div class="side-b">'
    sHtmlContent = oParser.abParse(sHtmlContent, sStart, sEnd)

    sPattern = '<a href="([^"]+)">([^<]+)'
    aResult = oParser.parse(sHtmlContent, sPattern)

    if not aResult[0]:
        oGui.addText(SITE_IDENTIFIER)
    TriAlpha = []
    if aResult[0]:
        for aEntry in aResult[1]:
            sUrl = aEntry[0]
            sTitle = aEntry[1].capitalize()
            TriAlpha.append((sTitle, sUrl))

        # Trie des genres par ordre alphabétique
        TriAlpha = sorted(TriAlpha, key=lambda genre: genre[0])

        oOutputParameterHandler = cOutputParameterHandler()
        for sTitle, sUrl in TriAlpha:
            oOutputParameterHandler.addParameter('siteUrl', sUrl)
            oGui.addGenre(SITE_IDENTIFIER, 'showMovies', sTitle, oOutputParameterHandler)
        oGui.setEndOfDirectory()


def showMovies(sSearch=''):
    oGui = cGui()
    oParser = cParser()
    URL_MAIN = getUrlMain()

    if sSearch:
        oUtil = cUtil()
        sSearchText = oUtil.CleanName(sSearch.replace('%20', ' '))

        URI = URL_MAIN + URL_SEARCH[0]
        oRequest = cRequestHandler(URI)
        pdata = 'do=search&subaction=search&story=' + sSearchText.replace(' ', '+') + '&titleonly=3&catlist[]=1&catlist[]=37&sortby=title&resorder=asc'

        oRequest.addHeaderEntry('Cookie', 'h_check=25')
        oRequest.addHeaderEntry('User-Agent', UA)
        oRequest.addHeaderEntry('Referer', URL_MAIN)# + URL_SEARCH[0])
        oRequest.addHeaderEntry('Origin', URL_MAIN)
        oRequest.addHeaderEntry('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
        oRequest.addHeaderEntry('Accept-Language', 'fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3')
        oRequest.addHeaderEntry('Content-Type', 'application/x-www-form-urlencoded')
        oRequest.addParametersLine(pdata)
        sHtmlContent = oRequest.request()

        sHtmlContent = oParser.abParse(sHtmlContent, '</script></form>')
        sPattern = 'mov clearfix.+?src="([^"]*)" *alt="([^"]*).+?link="([^"]+).+?(?:|bloc1">([^<]+).+?)(?:|bloc2">([^<]*).+?)'
        sPattern += 'ml-desc"> (?:([0-9]+)| ).+?Synopsis:.+?ml-desc">(.*?)<\/div'
        aResult = oParser.parse(sHtmlContent, sPattern)

        if not aResult[0]:
            pdata = 'do=search&subaction=search&story=' + sSearchText.replace(' ', '+') + '&titleonly=0&catlist[]=1&catlist[]=37&sortby=title&resorder=asc'
            oRequest.addParametersLine(pdata)
            sHtmlContent = oRequest.request()
            sHtmlContent = oParser.abParse(sHtmlContent, '</script></form>')
            aResult = oParser.parse(sHtmlContent, sPattern)
    else:
        oInputParameterHandler = cInputParameterHandler()
        sUrl = oInputParameterHandler.getValue('siteUrl')
        if not sUrl.startswith('http'):
            sUrl = URL_MAIN + sUrl
        oRequestHandler = cRequestHandler(sUrl)
        sHtmlContent = oRequestHandler.request()

        sPattern = 'mov clearfix.+?src="([^"]*)" *alt="([^"]*).+?link="([^"]+)'
        sPattern += '.+?bloc1">([^<]+).+?bloc2">([^<]*).+?Synopsis:.+?ml-desc">([^<]*)</div'

        aResult = oParser.parse(sHtmlContent, sPattern)

    if aResult[0]:
        oOutputParameterHandler = cOutputParameterHandler()

        for aEntry in aResult[1]:
            sThumb = aEntry[0]
            if sThumb.startswith('/'):
                sThumb = URL_MAIN[:-1] + aEntry[0]
            sTitle = aEntry[1].replace(' wiflix', '').replace(' flemmix', '')
            if 'serie-en-streaming' in aEntry[2]:
                sTitle = sTitle.replace(' - ', '')
            sUrl = aEntry[2]
            sLang = aEntry[3]
            sQual = aEntry[4]

            # Filtre de recherche
            if sSearch and not oUtil.CheckOccurence(sSearchText, sTitle):
                continue

            # Nettoyage du synopsis
            sDesc = str(aEntry[5])
            sDesc = sDesc.replace('en streaming ', '')
            sDesc = sDesc.replace('Regarder film ' + sTitle + ';', '')
            sDesc = sDesc.replace('Regarder film ' + sTitle + ':', '')
            sDesc = sDesc.replace('Voir film ' + sTitle + ';', '')
            sDesc = sDesc.replace('Voir film ' + sTitle + ':', '')
            sDesc = sDesc.replace('Voir Film ' + sTitle + ':', '')
            sDesc = sDesc.replace('Voir film ' + sTitle + ' :', '')
            sDesc = sDesc.replace('Regarder ' + sTitle + ';', '')
            sDesc = sDesc.replace('Regarder ' + sTitle + ' :', '')
            sDesc = sDesc.replace('Regarder ' + sTitle + ':', '')
            sDesc = sDesc.replace('voir ' + sTitle + ';', '')
            sDesc = sDesc.replace('voir ' + sTitle + ':', '')
            sDesc = sDesc.replace('Voir ' + sTitle + ':', '')
            sDesc = sDesc.replace('Regarder film ', '')
            sDesc = sDesc.strip()

            sDisplayTitle = '%s [%s] (%s)' % (sTitle, sQual, sLang)

            oOutputParameterHandler.addParameter('siteUrl', sUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)

            if 'serie-en-streaming' in sUrl:
                oGui.addSeason(SITE_IDENTIFIER, 'showEpisodes', sDisplayTitle, '', sThumb, sDesc, oOutputParameterHandler)
            else:
                oGui.addMovie(SITE_IDENTIFIER, 'showHosters', sDisplayTitle, '', sThumb, sDesc, oOutputParameterHandler)

        sNextPage, sPaging = __checkForNextPage(sHtmlContent)
        if sNextPage:
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sNextPage)
            oGui.addNext(SITE_IDENTIFIER, 'showMovies', 'Page ' + sPaging, oOutputParameterHandler)
    else:
        oGui.addText(SITE_IDENTIFIER)

    if not sSearch:
        oGui.setEndOfDirectory()


def __checkForNextPage(sHtmlContent):
    sPattern = '>([^<]+)</a> *</span>.*?<span class="pnext"><a href="([^"]+)'
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        sNumberMax = aResult[1][0][0]
        sNextPage = aResult[1][0][1]
        sNumberNext = re.search('page.([0-9]+)', sNextPage).group(1)
        sPaging = sNumberNext + '/' + sNumberMax
        return sNextPage, sPaging

    return False, 'none'


def showSeries(sSearch='', searchTitle = 3):
    oGui = cGui()
    oParser = cParser()
    URL_MAIN = getUrlMain()

    if sSearch:
        oUtil = cUtil()
        sSearchText = oUtil.CleanName(sSearch.replace('%20', ' '))
        sUrl = sSearch.replace(' ', '+')

        # requete sur la home pour obtenir le cookie
        # oRequest = cRequestHandler(URL_MAIN)
        # oRequest.addHeaderEntry('Referer', URL_MAIN)
        # oRequest.request()
        # cookie = oRequest.GetCookies()
        # if cookie:
        #     cookie += ';h_check=25'

        oRequest = cRequestHandler(URL_MAIN + URL_SEARCH[0])
        pdata = 'do=search&subaction=search&story=%s&titleonly=%d&all_word_search=1&catlist[]=31&catlist[]=35&sortby=title&resorder=asc' % (sUrl, searchTitle)

        # if cookie:
        #     oRequest.addHeaderEntry('Cookie', cookie)
        oRequest.addHeaderEntry('Cookie', 'h_check=25')
        oRequest.addHeaderEntry('User-Agent', UA)
        oRequest.addHeaderEntry('Referer', URL_MAIN)
        oRequest.addHeaderEntry('Origin', URL_MAIN)
        oRequest.addHeaderEntry('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
        oRequest.addHeaderEntry('Accept-Language', 'fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3')
        oRequest.addHeaderEntry('Content-Type', 'application/x-www-form-urlencoded')

        oRequest.addParametersLine(pdata)
        sHtmlContent = oRequest.request()
    else:
        oInputParameterHandler = cInputParameterHandler()
        sUrl = oInputParameterHandler.getValue('siteUrl')
        if not sUrl.startswith('http'):
            sUrl = URL_MAIN + sUrl
        oRequestHandler = cRequestHandler(sUrl)
        sHtmlContent = oRequestHandler.request()

    sPattern = 'mov clearfix.+?src="([^"]+)" *alt="([^"]+).+?data-link="([^"]+)'
    aResult = oParser.parse(sHtmlContent, sPattern)

    hasResult = False
    if aResult[0]:
        oOutputParameterHandler = cOutputParameterHandler()

        for aEntry in aResult[1]:
            sThumb = aEntry[0]
            if sThumb.startswith('/'):
                sThumb = URL_MAIN[:-1] + aEntry[0]

            sTitle = aEntry[1].replace('- Saison ', 'S').replace('wiflix', '').replace('flemmix', '').strip()

            # Filtre de recherche
            if sSearch and not oUtil.CheckOccurence(sSearchText, sTitle):
                continue

            hasResult = True
            sDisplayTitle = sTitle
            sUrl = aEntry[2]

            oOutputParameterHandler.addParameter('siteUrl', sUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
            oGui.addSeason(SITE_IDENTIFIER, 'showEpisodes', sDisplayTitle, '', sThumb, '', oOutputParameterHandler)

        sNextPage, sPaging = __checkForNextPage(sHtmlContent)
        if sNextPage:
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sNextPage)
            oGui.addNext(SITE_IDENTIFIER, 'showSeries', 'Page ' + sPaging, oOutputParameterHandler)

    #pas de résultats de recherche d'apres les articles, recherche dans les titres d'articles
    if sSearch and not hasResult and searchTitle == 3:
        if 'Access denied' not in sHtmlContent:
            showSeries(sSearch, searchTitle = 0)

    if not sSearch:
        oGui.setEndOfDirectory()


def showEpisodes():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()
    sPattern = '"clicbtn" rel="(ep\d+(vf|vs))" *>Episode (\d+)<'
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)

    # Afficher le numero de l episode et la saison dans le titre
    # permet de marquer vu avec trakt automatiquement.
    sLang = ''

    sMovieTitle = sMovieTitle.replace('saison ', 'S')

    if aResult[0]:
        oOutputParameterHandler = cOutputParameterHandler()
        for aEntry in aResult[1]:
            if aEntry[0]:

                if 'vs' in aEntry[1]:
                    sLang = ' (VOSTFR)'
                elif 'vf' in aEntry[1]:
                    sLang = ' (VF)'

                if 'epblocks' in aEntry[1]:
                    continue

                sTitle = '%s E%s' % (sMovieTitle, aEntry[2])
                sDisplayTitle = '%s %s' % (sTitle, sLang)
                oOutputParameterHandler.addParameter('siteUrl', '%s|%s' % (sUrl, aEntry[0]))
                oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
                oOutputParameterHandler.addParameter('sThumb', sThumb)

                oGui.addEpisode(SITE_IDENTIFIER, 'showHostersEpisode', sDisplayTitle, '', sThumb, '', oOutputParameterHandler)

    oGui.setEndOfDirectory()


def showHostersEpisode():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl, sID = oInputParameterHandler.getValue('siteUrl').split('|')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')

    oParser = cParser()
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()

    fx_k, _sl, _mu, _in = getFk(sHtmlContent)
    if fx_k:
        sStart = '<div class="%s"' % sID
        sEnd = '</div>'
        sHtmlContent = oParser.abParse(sHtmlContent, sStart, sEnd)
        sPattern = '<a data-v="([^"]+)'
        aResult = oParser.parse(sHtmlContent, sPattern)
    
        if aResult[0]:
            oHosterGui = cHosterGui()
            baseURL = urlHostName(sUrl)
            sUrlDecode = 'https://%s/ajax_player.php' % baseURL
            oRequest = cRequestHandler(sUrlDecode)
            oRequest.setRequestType(1)
            oRequest.addHeaderEntry('Referer', sUrl)
            oRequest.addHeaderEntry('Content-Type', 'application/x-www-form-urlencoded')
            
            for v in aResult[1]:
                fx_s = getFs(fx_k, _sl, _mu, _in, v)
                postdata = 'k=%s&b=1&t=1&s=%s&v=%s' % (fx_k, fx_s, v)
                oRequest.addParametersLine(postdata)
                ret = oRequest.request()
                if ret.startswith('{'):
                    ret = json.loads(ret)
                    sHosterUrl = ret.get('u', '')
                    if sHosterUrl:
                        oHoster = oHosterGui.checkHoster(sHosterUrl)
                        if oHoster:
                            oHoster.setDisplayName(sMovieTitle)
                            oHoster.setFileName(sMovieTitle)
                            oHosterGui.showHoster(oGui, oHoster, sHosterUrl, sThumb)

    oGui.setEndOfDirectory()


def showHosters():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')

    oParser = cParser()
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()
    sPattern = '<a data-v="([^"]+)".+?span data-n="([^"]+)'
    aResult = oParser.parse(sHtmlContent, sPattern)

    if aResult[0]:
        fx_k, _sl, _mu, _in = getFk(sHtmlContent)
        if fx_k:
            import base64
            oHosterGui = cHosterGui()
            baseURL = urlHostName(sUrl)
            sUrlDecode = 'https://%s/ajax_player.php' % baseURL
            oRequest = cRequestHandler(sUrlDecode)
            oRequest.setRequestType(1)
            oRequest.addHeaderEntry('Referer', sUrl)
            oRequest.addHeaderEntry('Content-Type', 'application/x-www-form-urlencoded')
            
            for aEntry in aResult[1]:
                sHoster = base64.b64decode(aEntry[1])
                sHoster = str(sHoster).strip("b'")
                oHoster = oHosterGui.checkHoster(sHoster)
                if oHoster:
                    v = aEntry[0]
                    fx_s = getFs(fx_k, _sl, _mu, _in, v)
                    postdata = 'k=%s&b=1&t=1&s=%s&v=%s' % (fx_k, fx_s, v)
                    oRequest.addParametersLine(postdata)
                    ret = oRequest.request()
                    if ret.startswith('{'):
                        ret = json.loads(ret)
                        sHosterUrl = ret.get('u', '')
                        if sHosterUrl:
                            oHoster.setDisplayName(sMovieTitle)
                            oHoster.setFileName(sMovieTitle)
                            oHosterGui.showHoster(oGui, oHoster, sHosterUrl, sThumb)

    oGui.setEndOfDirectory()


def getFk(html):
#    sHtmlContent = '<script data-cfasync="false">(function(){var _a=[24,73,76,75,16,78,28,75,73,26,30,16,24,24,25,25,84,24,29,30,74,76,25,16,78],_m=40,_in=3020,_mu=435,_d="";for(var i=0;i<_a.length;i++)_d+=String.fromCharCode(_a[i]^_m);var _sp=_d.split("|"),_k=_sp[0],_sl=_sp[1]||"";window._fx_k=_k;var _autoV="",_tr=0,_trTs=0,_ev=["pointerdown","mousedown","touchstart","keydown","click"];for(var j=0;j<_ev.length;j++){window.addEventListener(_ev[j],function(e){if(e&&e.isTrusted){_tr=5;_trTs=Date.now();}},true);}var _bot=false;try{if(navigator.webdriver||window._phantom||window.__nightmare||window.callPhantom||window._selenium||window.__webdriver_evaluate||window.__driver_evaluate||document.__webdriver_script_fn||window.domAutomation||window.domAutomationController)_bot=true;if(/HeadlessChrome|PhantomJS/i.test(navigator.userAgent||""))_bot=true;if(navigator.userAgentData&&navigator.userAgentData.brands){for(var b=0;b<navigator.userAgentData.brands.length;b++){if(/Headless/i.test(navigator.userAgentData.brands[b].brand||""))_bot=true;}}}catch(e){}function _sg(v,k){var s=v+"|"+k+"|"+_sl,h=_in;for(var c=0;c<s.length;c++)h=((h*_mu)+s.charCodeAt(c))&0x7fffffff;if(_bot)h=(h^0x5a5a5a)&0x7fffffff;return("00000000"+h.toString(16)).slice(-8);}var _oOpen=XMLHttpRequest.prototype.open,_oSend=XMLHttpRequest.prototype.send;XMLHttpRequest.prototype.open=function(m,u){this._fxP=(typeof u==="string"&&u.indexOf("ajax_player.php")!==-1);return _oOpen.apply(this,arguments);};XMLHttpRequest.prototype.send=function(body){if(this._fxP&&typeof body==="string"&&body.indexOf("v=")!==-1&&body.indexOf("&s=")===-1){var m=body.match(/(?:^|&)v=([^&]+)/);var vVal=m?decodeURIComponent(m[1]):"";var ok=0;if(!_autoV||_autoV===vVal){_autoV=vVal;ok=1;}else if(_tr>0||(Date.now()-_trTs)<1500){if(_tr>0)_tr--;ok=1;}if(_bot)ok=0;if(body.indexOf("&k=&")!==-1)body=body.replace("&k=&","&k="+encodeURIComponent(_k)+"&");body+="&s="+encodeURIComponent(_sg(vVal,_k))+"&t="+ok;return _oSend.call(this,body);}return _oSend.apply(this,arguments);};})();</script>'
    oParser = cParser()
    html = oParser.abParse(html, '(function(){var _a=', '</script>')
    match_a = re.search(r'var\s+_a\s*=\s*\[([^\]]+)\]', html)
    match_m = re.search(r'\b_m\s*=\s*(\d+)', html)
    match_in = re.search(r'\b_in\s*=\s*(\d+)', html)
    match_mu = re.search(r'\b_mu\s*=\s*(\d+)', html)

    if not (match_a and match_m and match_in and match_mu):
        return None, None, None, None

    _a = [int(x.strip()) for x in match_a.group(1).split(',')]
    _m = int(match_m.group(1))
    _in = int(match_in.group(1))
    _mu = int(match_mu.group(1))

    # Décodage
    _d = ''.join(chr(x ^ _m) for x in _a)
    _sp = _d.split('|')
    _k = _sp[0]
    _sl = _sp[1] if len(_sp) > 1 else ''

    return _k, _sl, _mu, _in

# Calcul de la signature
def getFs(_k, _sl, _mu, _in, v):
    s = v + '|' + _k + '|' + _sl
    for c in s:
        _in = ((_in * _mu) + ord(c)) & 0x7fffffff
    return ('00000000' + format(_in, 'x'))[-8:]
